# Documentação técnica relativa ao serviço de autenticação do Autenticação.Gov<span> e Chave Móvel Digital




## Estrutura de pastas

* Na pasta **PRÉ-PRODUÇÃO** encontra-se o ficheiro P7B  que contem o certificado SAML utilizado pelo Autenticação.Gov<span> e a respetiva hierarquia de certificados. O certificado deverá ser utilizado para confirmação da origem e validação das respostas SAML enviadas pelo Autenticação.Gov<span> do ambiente de pré-produção. 
  * O thumprint SHA-1 do certificado é **80D586875344857DB29B7EAD63D50FB1CB767DF4**
 
* Na pasta **PRODUÇÃO** encontra-se o ficheiro P7B  que contem o certificado SAML utilizado pelo Autenticação.Gov<span> e a respetiva hierarquia de certificados. O certificado deverá ser utilizado para confirmação da origem e validação das respostas SAML enviadas pelo Autenticação.Gov<span> do ambiente de produção.
  * O thumprint SHA-1 do certificado é **9C91184D254E2065F97E5CF8F6EAE89A5CD30687**

## Contactos
Para questões, sugestões ou comentários envie um e-mail para eid@ama.pt.
