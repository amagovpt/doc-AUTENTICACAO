﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ServiceProviderSample
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ((LinkButton)this.Master.FindControl("LinkButtonHome")).Style.Add("font-weight", "bold");
                ((LinkButton)this.Master.FindControl("LinkButtonPrivate")).Style.Remove("font-weight");
            }
        }
    }
}
