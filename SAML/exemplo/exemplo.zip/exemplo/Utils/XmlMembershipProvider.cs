﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Xml;
using System.Web.Hosting;

namespace ServiceProviderSample.Utils
{
    public class XmlMembershipProvider : MembershipProvider
    {
        private string _AppName;
        private Dictionary<string, MembershipUser> _MyUsers;
        private string _FileName;

        public override void Initialize(string name, System.Collections.Specialized.NameValueCollection config)
        {
            base.Initialize(name, config);

            _AppName = config["applicationName"];
            if (string.IsNullOrEmpty(_AppName))
            {
                _AppName = "/";
            }

            _FileName = config["xmlUserDatabaseFile"];
            if (string.IsNullOrEmpty(_FileName))
            {
                _FileName = "~/App_Data/UserDatabase.xml";
            }
        }

        public override string ApplicationName
        {
            get
            {
                return _AppName;
            }
            set
            {
                _AppName = value;
            }
        }

        public override bool ChangePassword(string username, string oldPassword, string newPassword)
        {
            return false;
        }

        public override bool ChangePasswordQuestionAndAnswer(string username, string password, string newPasswordQuestion, string newPasswordAnswer)
        {
            throw new NotImplementedException();
        }

        public override MembershipUser CreateUser(string username, string password, string email, string passwordQuestion, string passwordAnswer, bool isApproved, object providerUserKey, out MembershipCreateStatus status)
        {
            MembershipUser mu = null;

            if (_MyUsers == null)
                ReadUserFile();

            if (!_MyUsers.TryGetValue(username, out mu))
            {
                mu = new MembershipUser(Name,
                              username,
                              null,
                              email,
                              passwordQuestion,
                              password,
                              true,
                              false,
                              DateTime.Now,
                              DateTime.Now,
                              DateTime.Now,
                              DateTime.Now,
                              DateTime.Now);

                _MyUsers.Add(mu.UserName, mu);

                // adicionar à base de dados:
                lock (this)
                {
                    XmlDocument xd = new XmlDocument();
                    xd.Load(HostingEnvironment.MapPath(_FileName));
                    XmlNode root = xd.DocumentElement;

                    XmlElement _username = xd.CreateElement("Username");
                    _username.InnerText = mu.UserName;
                    XmlElement _password = xd.CreateElement("Password");
                    _password.InnerText = mu.Comment;
                    XmlElement _email = xd.CreateElement("Email");
                    _email.InnerText = mu.Email;
                    XmlElement _dateCreated = xd.CreateElement("DateCreated");
                    _dateCreated.InnerText = DateTime.Now.ToShortDateString();

                    XmlElement _user = xd.CreateElement("User");
                    _user.AppendChild(_username);
                    _user.AppendChild(_password);
                    _user.AppendChild(_email);
                    _user.AppendChild(_dateCreated);

                    root.AppendChild(_user);

                    xd.Save(HostingEnvironment.MapPath(_FileName));
                }
            }            

            status = 0; // ?? significado?
            return mu;
        }

        public override bool DeleteUser(string username, bool deleteAllRelatedData)
        {
            throw new NotImplementedException();
        }

        public override bool EnablePasswordReset
        {
            get { throw new NotImplementedException(); }
        }

        public override bool EnablePasswordRetrieval
        {
            get { throw new NotImplementedException(); }
        }

        public override MembershipUserCollection FindUsersByEmail(string emailToMatch, int pageIndex, int pageSize, out int totalRecords)
        {
            throw new NotImplementedException();
        }

        public override MembershipUserCollection FindUsersByName(string usernameToMatch, int pageIndex, int pageSize, out int totalRecords)
        {
            throw new NotImplementedException();
        }

        public override MembershipUserCollection GetAllUsers(int pageIndex, int pageSize, out int totalRecords)
        {
            throw new NotImplementedException();
        }

        public override int GetNumberOfUsersOnline()
        {
            throw new NotImplementedException();
        }

        public override string GetPassword(string username, string answer)
        {
            throw new NotImplementedException();
        }

        public override MembershipUser GetUser(string username, bool userIsOnline)
        {
            if (String.IsNullOrEmpty(username))
            {
                return null;
            }

            try
            {
                ReadUserFile();

                MembershipUser mu;

                if (_MyUsers.TryGetValue(username.ToLower(), out mu))
                    return mu;
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        public override MembershipUser GetUser(object providerUserKey, bool userIsOnline)
        {
            throw new NotImplementedException();
        }

        public override string GetUserNameByEmail(string email)
        {
            throw new NotImplementedException();
        }

        public override int MaxInvalidPasswordAttempts
        {
            get { throw new NotImplementedException(); }
        }

        public override int MinRequiredNonAlphanumericCharacters
        {
            get { throw new NotImplementedException(); }
        }

        public override int MinRequiredPasswordLength
        {
            get { return 6; }
        }

        public override int PasswordAttemptWindow
        {
            get { throw new NotImplementedException(); }
        }

        public override MembershipPasswordFormat PasswordFormat
        {
            get { throw new NotImplementedException(); }
        }

        public override string PasswordStrengthRegularExpression
        {
            get { throw new NotImplementedException(); }
        }

        public override bool RequiresQuestionAndAnswer
        {
            get { return false; }
        }

        public override bool RequiresUniqueEmail
        {
            get { throw new NotImplementedException(); }
        }

        public override string ResetPassword(string username, string answer)
        {
            throw new NotImplementedException();
        }

        public override bool UnlockUser(string userName)
        {
            throw new NotImplementedException();
        }

        public override void UpdateUser(MembershipUser user)
        {
            throw new NotImplementedException();
        }

        public override bool ValidateUser(string username, string password)
        {
            if (String.IsNullOrEmpty(username) || String.IsNullOrEmpty(password))
            {
                return false;
            }

            try
            {
                ReadUserFile();

                MembershipUser mu;

                if (_MyUsers.TryGetValue(username.ToLower(), out mu))
                {
                    if (mu.Comment == password)
                    {
                        return true;
                    }
                }

                return false;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        private void ReadUserFile()
        {
            if (_MyUsers == null)
            {
                lock (this)
                {
                    _MyUsers = new Dictionary<string, MembershipUser>();
                    XmlDocument xd = new XmlDocument();
                    xd.Load(HostingEnvironment.MapPath(_FileName));
                    XmlNodeList xnl = xd.GetElementsByTagName("User");

                    foreach (XmlNode node in xnl)
                    {
                        MembershipUser mu = new MembershipUser(Name,
                           node["Username"].InnerText,
                           null,
                           node["Email"].InnerText,
                           String.Empty,
                           node["Password"].InnerText,
                           true,
                           false,
                           DateTime.Parse(node["DateCreated"].InnerText),
                           DateTime.Now,
                           DateTime.Now,
                           DateTime.Now,
                           DateTime.Now);

                        _MyUsers.Add(mu.UserName.ToLower(), mu);
                    }
                }
            }
        }
    }
}